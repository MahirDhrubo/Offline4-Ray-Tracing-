#include<bits/stdc++.h>
#include<windows.h>
#include<GL/glut.h>

#include "1705113_classes.h"

int main(){
    Point point(1,2,3.5);

    point.print();
}
